angular-base-64-upload-demo
===========================

![alt tag](https://raw.github.com/adonespitogo/angular-base64-upload/master/banner.png)

Running
-------
<p>Inside your clone's directory:</p>

```
$ cd demo/
$ php -S 127.0.0.1:8000
```
