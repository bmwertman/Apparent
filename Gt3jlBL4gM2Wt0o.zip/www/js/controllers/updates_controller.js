Pta.controller([
  '$scope',
  function($scope){
}]);